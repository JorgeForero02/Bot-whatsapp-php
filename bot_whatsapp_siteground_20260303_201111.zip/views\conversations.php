<?php
$pageTitle   = 'Conversaciones - WhatsApp Bot';
$currentPage = 'conversations';

ob_start();
?>

<style>
.conv-panel { display:flex; flex-direction:column; background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-xl); overflow:hidden; }
.conv-filter-btn { flex:1; padding:0.4375rem 0.75rem; font-size:0.8125rem; font-weight:500; border-radius:var(--radius-md); border:1px solid var(--border-color); background:transparent; color:var(--text-secondary); cursor:pointer; transition:all 0.15s ease; min-height:36px; }
.conv-filter-btn.active { background:var(--color-primary); color:#fff; border-color:var(--color-primary); }
.conv-filter-btn:hover:not(.active) { background:var(--bg-elevated); }
.conv-item { display:flex; align-items:center; gap:0.75rem; padding:0.875rem 1rem; border-bottom:1px solid var(--border-subtle); cursor:pointer; transition:background 0.15s ease; }
.conv-item:hover { background:var(--bg-elevated); }
.conv-item.selected { background:var(--bg-elevated); border-left:3px solid var(--color-primary); }
@media (max-width:767px) {
  #list-panel  { display:flex !important; }
  #chat-panel  { display:none !important; }
  #chat-panel.mobile-open { display:flex !important; }
  #list-panel.mobile-hidden { display:none !important; }
}
</style>

<div style="display:flex;gap:1rem;height:calc(100vh - 120px);min-height:500px;">
  <!-- ── List panel ── -->
  <div id="list-panel" class="conv-panel" style="width:320px;flex-shrink:0;">
    <!-- Search + filters -->
    <div style="padding:0.75rem;border-bottom:1px solid var(--border-color);flex-shrink:0;">
      <div style="display:flex;gap:0.375rem;margin-bottom:0.625rem;">
        <button class="conv-filter-btn active" id="filter-all"     onclick="filterConversations('all')">Todas</button>
        <button class="conv-filter-btn"        id="filter-active"  onclick="filterConversations('active')">Activas</button>
        <button class="conv-filter-btn"        id="filter-pending" onclick="filterConversations('pending_human')">Pendientes</button>
      </div>
      <div style="position:relative;">
        <input type="text" id="search-conversations"
               class="form-input" style="padding-left:2.25rem;"
               placeholder="Buscar por nombre o número…">
        <svg style="position:absolute;left:0.625rem;top:50%;transform:translateY(-50%);width:1rem;height:1rem;color:var(--text-muted);pointer-events:none;"
             viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"/>
        </svg>
      </div>
    </div>
    <!-- Conversations list -->
    <div id="conversations-list" style="flex:1;overflow-y:auto;">
      <div style="display:flex;align-items:center;justify-content:center;padding:3rem;">
        <div class="spinner"></div>
      </div>
    </div>
  </div>
        
  <!-- ── Chat panel ── -->
  <div id="chat-panel" class="conv-panel" style="flex:1;min-width:0;">

    <!-- Chat header -->
    <div id="chat-header" class="hidden" style="padding:0.875rem 1rem;border-bottom:1px solid var(--border-color);display:flex;align-items:center;gap:0.75rem;flex-shrink:0;">
      <!-- Back button (mobile) -->
      <button onclick="closeChat()" id="back-btn"
              style="display:none;padding:0.375rem;border-radius:var(--radius-md);border:1px solid var(--border-color);background:transparent;cursor:pointer;color:var(--text-secondary);flex-shrink:0;"
              aria-label="Volver">
        <svg width="18" height="18" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"/>
        </svg>
      </button>
      <!-- Avatar -->
      <div class="avatar avatar-md" id="chat-avatar" style="flex-shrink:0;">?</div>
      <!-- Name / phone -->
      <div style="flex:1;min-width:0;">
        <div style="font-size:0.9375rem;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" id="chat-contact-name"></div>
        <div style="font-size:0.8125rem;color:var(--text-muted);" id="chat-contact-phone"></div>
      </div>
      <!-- AI toggle -->
      <div style="display:flex;align-items:center;gap:0.5rem;flex-shrink:0;">
        <span style="font-size:0.75rem;font-weight:500;color:var(--text-secondary);">IA Bot</span>
        <label class="toggle" title="Activar/desactivar IA">
          <input type="checkbox" id="ai-toggle" onchange="toggleAI()">
          <span class="toggle-thumb"></span>
        </label>
      </div>
    </div>

    <!-- Messages area -->
    <div id="chat-messages" class="chat-container" style="flex:1;overflow-y:auto;padding:1rem;">
      <button id="load-more-btn" class="hidden btn btn-secondary btn-sm" style="width:100%;margin-bottom:1rem;" onclick="loadMoreMessages()">
        Cargar mensajes anteriores
      </button>
      <div id="messages-content">
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;min-height:300px;color:var(--text-muted);text-align:center;gap:0.75rem;padding:2rem;">
          <svg width="56" height="56" viewBox="0 0 20 20" fill="currentColor" style="opacity:0.2;">
            <path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7z" clip-rule="evenodd"/>
          </svg>
          <p style="font-size:1rem;font-weight:500;color:var(--text-secondary);">Selecciona una conversación</p>
          <p style="font-size:0.875rem;">Elige una conversación de la lista para ver los mensajes</p>
        </div>
      </div>
    </div>

    <!-- Reply input -->
    <div id="chat-input" class="hidden" style="padding:0.875rem 1rem;border-top:1px solid var(--border-color);flex-shrink:0;">
      <div style="display:flex;align-items:flex-end;gap:0.625rem;">
        <textarea id="reply-input"
                  class="form-textarea"
                  placeholder="Escribe tu respuesta… (Enter para enviar, Shift+Enter para nueva línea)"
                  rows="1"
                  style="flex:1;resize:none;max-height:120px;border-radius:var(--radius-lg);"></textarea>
        <button id="send-btn" onclick="sendReply()" class="btn btn-primary btn-md" style="flex-shrink:0;">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/>
          </svg>
          Enviar
        </button>
      </div>
    </div>
  </div>

</div>

<script>
(function() {
  /* Show back button on mobile */
  function syncBackBtn() {
    var btn = document.getElementById('back-btn');
    if (btn) btn.style.display = window.innerWidth < 768 ? 'flex' : 'none';
  }
  syncBackBtn();
  window.addEventListener('resize', syncBackBtn);

  /* Mobile: when viewConversation is called, switch panels */
  var origView = window.viewConversation;
  if (origView) {
    window._origViewConversation = origView;
    window.viewConversation = function(id, name, phone) {
      origView(id, name, phone);
      if (window.innerWidth < 768) {
        document.getElementById('list-panel').classList.add('mobile-hidden');
        document.getElementById('chat-panel').classList.add('mobile-open');
        document.getElementById('chat-panel').style.display = 'flex';
      }
      /* update avatar initial */
      var avatarEl = document.getElementById('chat-avatar');
      if (avatarEl) avatarEl.textContent = (name || '?').charAt(0).toUpperCase();
    };
  }

  /* Mobile: closeChat restores list */
  var origClose = window.closeChat;
  if (origClose) {
    window._origCloseChat = origClose;
    window.closeChat = function() {
      origClose();
      if (window.innerWidth < 768) {
        document.getElementById('list-panel').classList.remove('mobile-hidden');
        document.getElementById('chat-panel').classList.remove('mobile-open');
        document.getElementById('chat-panel').style.display = '';
      }
      var avatarEl = document.getElementById('chat-avatar');
      if (avatarEl) avatarEl.textContent = '?';
    };
  }
})();
</script>

<?php
$content = ob_get_clean();

$scripts = '';
$extraScripts = '<script src="' . (defined('BASE_PATH') ? BASE_PATH : '') . '/assets/js/conversations.js"></script>';

require __DIR__ . '/layout.php';
?>
