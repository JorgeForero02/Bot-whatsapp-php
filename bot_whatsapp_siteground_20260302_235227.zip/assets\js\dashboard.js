/* Dashboard JS */
(function() {

const bp = typeof BASE_PATH !== 'undefined' ? BASE_PATH : '';

/* ── Chart.js 4.4.4 ── */
let chartInstance = null;

function initChart(labels, data) {
  const canvas = document.getElementById('messages-chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  const tickColor = isDark ? '#475569' : '#94a3b8';

  const gradient = ctx.createLinearGradient(0, 0, 0, 180);
  gradient.addColorStop(0, 'rgba(7,94,84,0.25)');
  gradient.addColorStop(1, 'rgba(7,94,84,0)');

  if (chartInstance) chartInstance.destroy();

  chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Mensajes',
        data,
        fill: true,
        backgroundColor: gradient,
        borderColor: '#075E54',
        borderWidth: 2,
        pointBackgroundColor: '#075E54',
        pointRadius: 3,
        pointHoverRadius: 5,
        tension: 0.4,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: isDark ? '#1a1a24' : '#ffffff',
          titleColor: isDark ? '#f1f5f9' : '#0f172a',
          bodyColor: isDark ? '#94a3b8' : '#475569',
          borderColor: isDark ? '#1e1e2e' : '#e2e8f0',
          borderWidth: 1,
          padding: 10,
        }
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: tickColor, font: { size: 11 } }
        },
        y: {
          beginAtZero: true,
          grid: { color: gridColor },
          ticks: { color: tickColor, font: { size: 11 }, maxTicksLimit: 5 }
        }
      }
    }
  });
}

/* ── Stat card update ── */
function setStatCard(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

/* ── Service status row ── */
function renderServices(waOk, oaiOk, gcOk) {
  const services = [
    { label: 'WhatsApp',       ok: waOk,  href: bp + '/credentials',       icon: '<svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7z" clip-rule="evenodd"/></svg>' },
    { label: 'OpenAI',         ok: oaiOk, href: bp + '/credentials',       icon: '<svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>' },
    { label: 'Google Calendar', ok: gcOk, href: bp + '/credentials',       icon: '<svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/></svg>' },
  ];

  const html = services.map(s => {
    const statusClass = s.ok === true ? 'badge-success' : s.ok === false ? 'badge-warning' : 'badge-neutral';
    const statusText  = s.ok === true ? 'Conectado' : s.ok === false ? 'Sin configurar' : 'Verificando';
    return `
      <div style="display:flex;align-items:center;padding:0.75rem 1.25rem;border-bottom:1px solid var(--border-subtle);">
        <span style="color:var(--text-muted);margin-right:0.625rem;display:flex;">${s.icon}</span>
        <span style="font-size:0.875rem;font-weight:500;color:var(--text-secondary);flex:1;">${s.label}</span>
        <span class="badge ${statusClass}">${statusText}</span>
        ${s.ok !== true ? `<a href="${s.href}" style="font-size:0.75rem;color:var(--color-primary);text-decoration:none;margin-left:0.75rem;">Configurar</a>` : ''}
      </div>
    `;
  }).join('');

  const container = document.getElementById('services-list');
  if (container) container.innerHTML = html;
}

/* ── Recent conversations ── */
function renderRecentConvs(conversations) {
  const container = document.getElementById('recent-convs');
  if (!container) return;

  if (!conversations || conversations.length === 0) {
    container.innerHTML = `
      <div style="padding:2rem;text-align:center;color:var(--text-muted);font-size:0.875rem;">
        No hay conversaciones recientes
      </div>`;
    return;
  }

  const statusMap = {
    active:        { cls: 'badge-success', label: 'Activa' },
    pending_human: { cls: 'badge-warning', label: 'Pendiente' },
    closed:        { cls: 'badge-neutral', label: 'Cerrada' },
  };

  const html = conversations.slice(0, 6).map(conv => {
    const initial   = (conv.contact_name || conv.phone_number || '?').charAt(0).toUpperCase();
    const name      = conv.contact_name || conv.phone_number || 'Sin nombre';
    const preview   = (conv.last_message || 'Sin mensajes').substring(0, 45);
    const timeAgo   = window.formatTimeAgo ? window.formatTimeAgo(conv.last_message_at) : '';
    const s         = statusMap[conv.status] || statusMap.closed;
    return `
      <a href="${bp}/conversations" style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1.25rem;border-bottom:1px solid var(--border-subtle);text-decoration:none;transition:background 0.15s ease;" 
         onmouseover="this.style.background='var(--bg-elevated)'" onmouseout="this.style.background=''">
        <div class="avatar avatar-sm" style="background:var(--color-primary);flex-shrink:0;">${escapeHtml(initial)}</div>
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.125rem;">
            <span style="font-size:0.875rem;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:140px;">${escapeHtml(name)}</span>
            <span style="font-size:0.6875rem;color:var(--text-muted);flex-shrink:0;margin-left:0.5rem;">${escapeHtml(timeAgo)}</span>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:0.5rem;">
            <span style="font-size:0.8125rem;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(preview)}${(conv.last_message || '').length > 45 ? '…' : ''}</span>
            <span class="badge ${s.cls}" style="flex-shrink:0;">${s.label}</span>
          </div>
        </div>
      </a>
    `;
  }).join('');

  container.innerHTML = html;
}

/* ── Calendar events ── */
function renderCalendarEvents(events, calendarEnabled) {
  const container = document.getElementById('calendar-events');
  if (!container) return;

  if (!calendarEnabled) {
    container.innerHTML = `
      <div style="padding:1.5rem 1.25rem;text-align:center;">
        <span class="badge badge-neutral" style="margin-bottom:0.5rem;">Desactivado</span>
        <p style="font-size:0.8125rem;color:var(--text-muted);">Activa Google Calendar en <a href="${bp}/credentials" style="color:var(--color-primary);">Credenciales</a></p>
      </div>`;
    return;
  }

  if (!events || events.length === 0) {
    container.innerHTML = `
      <div style="padding:2rem;text-align:center;color:var(--text-muted);font-size:0.875rem;">
        No hay citas programadas para hoy
      </div>`;
    return;
  }

  const html = events.slice(0, 4).map(ev => {
    const time = ev.start_time || '';
    return `
      <div style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1.25rem;border-bottom:1px solid var(--border-subtle);">
        <div style="width:2.5rem;height:2.5rem;border-radius:var(--radius-md);background:rgba(7,94,84,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="var(--color-primary)">
            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
          </svg>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:0.875rem;font-weight:500;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(ev.title || 'Cita')}</div>
          <div style="font-size:0.75rem;color:var(--text-muted);">${escapeHtml(time)}</div>
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = html;
}

/* ── Escape helper ── */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

/* ── Main load function ── */
async function loadDashboard() {
  try {
    /* Stats */
    const [statsRes, convsRes, connRes, settingsRes] = await Promise.allSettled([
      fetch(bp + '/api/get-stats.php'),
      fetch(bp + '/api/get-conversations.php?limit=6'),
      fetch(bp + '/api/test-connection.php?service=whatsapp'),
      fetch(bp + '/api/get-settings.php'),
    ]);

    /* Stats */
    if (statsRes.status === 'fulfilled') {
      const d = await statsRes.value.json();
      if (d.success && d.stats) {
        const s = d.stats;
        setStatCard('sc-today-val',    s.conversations.today ?? s.conversations.active ?? '—');
        setStatCard('sc-messages-val', s.conversations.total_messages ?? '—');
        setStatCard('sc-pending-val',  s.conversations.pending_human ?? '—');
        setStatCard('sc-docs-val',     s.documents.total ?? '—');

        /* Chart data — use daily_messages if provided, else mock 7 days */
        const chartData   = s.daily_messages || Array(7).fill(0);
        const today       = new Date();
        const chartLabels = Array.from({ length: 7 }, (_, i) => {
          const d = new Date(today);
          d.setDate(today.getDate() - (6 - i));
          return d.toLocaleDateString('es', { weekday: 'short', day: 'numeric' });
        });
        if (typeof Chart !== 'undefined') initChart(chartLabels, chartData);
      }
    }

    /* Recent conversations */
    if (convsRes.status === 'fulfilled') {
      const d = await convsRes.value.json();
      if (d.success) renderRecentConvs(d.conversations || []);
    } else {
      renderRecentConvs([]);
    }

    /* Settings → calendar enabled + bot mode */
    let calendarEnabled = false;
    if (settingsRes.status === 'fulfilled') {
      const d = await settingsRes.value.json();
      if (d.success && d.settings) calendarEnabled = d.settings.calendarEnabled ?? false;
    }

    /* Service statuses via test-connection */
    let waOk = null, oaiOk = null, gcOk = null;
    try {
      const [waRes, oaiRes, gcRes] = await Promise.allSettled([
        fetch(bp + '/api/test-connection.php?service=whatsapp'),
        fetch(bp + '/api/test-connection.php?service=openai'),
        fetch(bp + '/api/test-connection.php?service=google'),
      ]);
      const parse = async r => { if (r.status === 'fulfilled') { try { const d = await r.value.json(); return d.success; } catch { return null; } } return null; };
      waOk  = await parse(waRes);
      oaiOk = await parse(oaiRes);
      gcOk  = calendarEnabled ? await parse(gcRes) : false;
    } catch(_) {}
    renderServices(waOk, oaiOk, gcOk);

    /* Calendar events — only if enabled (API may not exist, silently ignore) */
    if (calendarEnabled) {
      try {
        const gcEvRes = await fetch(bp + '/api/get-calendar-settings.php');
        const gcEvData = await gcEvRes.json();
        renderCalendarEvents(gcEvData.upcoming_events || [], true);
      } catch(_) { renderCalendarEvents([], true); }
    } else {
      renderCalendarEvents([], false);
    }

  } catch (err) {
    console.error('Dashboard load error:', err);
  }
}

/* ── Onboarding banner ── */
async function loadOnboardingBanner() {
  try {
    const res  = await fetch(bp + '/api/onboarding-progress.php');
    const data = await res.json();
    if (!data.success) return;

    const banner = document.getElementById('onboarding-banner');
    if (!banner) return;

    if (data.complete) {
      banner.style.display = '';
      banner.innerHTML = `
        <div class="alert alert-success" style="justify-content:space-between;">
          <span class="alert-icon"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clip-rule="evenodd"/></svg></span>
          <div style="flex:1;">
            <p style="font-weight:600;">Configuración completa</p>
            <p style="font-size:0.8125rem;opacity:0.85;">Tu bot está activo y correctamente configurado.</p>
          </div>
          <a href="${bp}/onboarding" style="font-size:0.8125rem;font-weight:500;text-decoration:underline;flex-shrink:0;">Reconfigurar</a>
        </div>`;
    } else {
      const steps = data.steps || [];
      const done  = steps.filter(s => s.is_completed || s.is_skipped).length;
      const total = steps.length;
      const pct   = total > 0 ? Math.round((done / total) * 100) : 0;
      banner.style.display = '';
      banner.innerHTML = `
        <div class="alert alert-warning" style="justify-content:space-between;flex-wrap:wrap;gap:0.75rem;">
          <span class="alert-icon"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"/></svg></span>
          <div style="flex:1;min-width:200px;">
            <p style="font-weight:600;">Configuración en progreso — ${done}/${total} pasos</p>
            <div style="margin-top:0.375rem;height:4px;border-radius:2px;background:rgba(217,119,6,0.2);overflow:hidden;">
              <div style="height:100%;width:${pct}%;background:var(--color-warning);border-radius:2px;transition:width 0.5s ease;"></div>
            </div>
          </div>
          <a href="${bp}/onboarding" class="btn btn-sm" style="background:var(--color-warning);color:#fff;flex-shrink:0;">Continuar configuración</a>
        </div>`;
    }
  } catch(e) { /* silently ignore */ }
}

/* ── Init ── */
loadDashboard();
loadOnboardingBanner();

/* Visibility-aware auto-refresh every 30s */
if (window.visibilityInterval) {
  visibilityInterval(loadDashboard, 30000);
} else {
  setInterval(loadDashboard, 30000);
}

})();
