# 📂 Estructura del Proyecto - Bot WhatsApp PHP

## ✅ Archivos Verificados

### 🔧 Configuración Base
```
├── .env                          ✅ Credenciales (NO subir a Git)
├── .gitignore                    ✅ Configuración Git
├── .htaccess                     ✅ Rewrite rules para Apache
├── composer.json                 ✅ Dependencias PHP
├── index.php                     ✅ Router principal (soporta subcarpetas)
├── webhook.php                   ✅ Endpoint WhatsApp Business
├── check_system.php              ✅ Diagnóstico del sistema
└── DEPLOY_SITEGROUND.md          ✅ Guía de deployment
```

### 📁 Carpetas Principales

#### `/api/` - REST API Endpoints (15 archivos)
```
✅ check-conversation-updates.php  - Polling de actualizaciones
✅ check-openai-status.php        - Estado de OpenAI
✅ check-updates.php               - Updates de mensajes
✅ delete-document.php             - Eliminar documentos
✅ get-conversation-messages.php  - Mensajes de conversación
✅ get-conversations.php           - Lista conversaciones
✅ get-document-content.php        - Contenido de documentos
✅ get-documents.php               - Lista documentos
✅ get-settings.php                - Configuración
✅ get-stats.php                   - Estadísticas dashboard
✅ health.php                      - Health check
✅ reply-conversation.php          - Responder mensajes
✅ save-settings.php               - Guardar configuración
✅ toggle-ai.php                   - Activar/desactivar IA
✅ upload.php                      - Subir documentos
```

#### `/src/` - Código Fuente (12 archivos)

**Core:**
```
✅ Core/Config.php                 - Gestión de configuración
✅ Core/Database.php               - Conexión MySQL
✅ Core/Logger.php                 - Sistema de logs
```

**Services:**
```
✅ Services/ConversationService.php      - Gestión conversaciones
✅ Services/DocumentService.php          - Procesamiento documentos
✅ Services/GoogleCalendarService.php    - Integración Calendar
✅ Services/OpenAIService.php            - API OpenAI + Whisper
✅ Services/RAGService.php               - Retrieval Augmented Generation
✅ Services/VectorSearchService.php      - Búsqueda vectorial
✅ Services/WhatsAppService.php          - API WhatsApp Business
```

**Utils:**
```
✅ Utils/TextProcessor.php         - Procesamiento de texto
✅ Utils/VectorMath.php            - Matemáticas vectoriales
```

#### `/views/` - Frontend (5 archivos)
```
✅ layout.php                      - Template base (con BASE_PATH)
✅ dashboard.php                   - Panel principal
✅ conversations.php               - Gestión conversaciones
✅ documents.php                   - Gestión documentos RAG
✅ settings.php                    - Configuración sistema
```

#### `/config/` - Configuración
```
✅ config.php                      - Archivo configuración principal
```

#### `/database/` - Base de Datos
```
✅ schema.sql                      - Schema completo consolidado
```

#### `/workers/` - Procesamiento Asíncrono
```
✅ process-embeddings.php          - Generación de embeddings
```

#### `/vendor/` - Dependencias Composer
```
✅ vendor/autoload.php             - Autoloader Composer
✅ vendor/guzzlehttp/              - HTTP client
✅ vendor/phpoffice/               - Procesamiento Word
✅ vendor/smalot/                  - Procesamiento PDF
✅ vendor/psr/                     - PSR interfaces
✅ vendor/composer/                - Composer metadata
```

#### Carpetas de Runtime (creadas automáticamente)
```
logs/                              - Logs de aplicación
uploads/                           - Archivos subidos
  ├── audios/                      - Audios de WhatsApp
  └── documents/                   - Documentos RAG
```

---

## 🔍 Verificación de Integridad

### ✅ Archivos Críticos Verificados

1. **index.php** - ✅ Detecta subcarpetas automáticamente
2. **webhook.php** - ✅ Procesa mensajes WhatsApp
3. **config/config.php** - ✅ Lee variables .env
4. **database/schema.sql** - ✅ Schema consolidado
5. **views/layout.php** - ✅ BASE_PATH para subcarpetas
6. **All API endpoints** - ✅ 15 archivos funcionales
7. **All Services** - ✅ 7 servicios principales
8. **check_system.php** - ✅ Diagnóstico completo

### 🔗 Dependencias Externas

**Composer (vendor/):**
- guzzlehttp/guzzle ^7.0
- phpoffice/phpword ^0.18
- smalot/pdfparser ^0.18

**CDN:**
- TailwindCSS (via CDN)
- Google Fonts (Inter)

**APIs Externas:**
- WhatsApp Business API (Meta)
- OpenAI API (GPT + Whisper)
- Google Calendar API

---

## 📋 Checklist Pre-Deployment

### Archivos Requeridos
- [x] vendor/ completa con autoload
- [x] src/ con todas las clases
- [x] api/ con todos los endpoints
- [x] views/ con todos los templates
- [x] config/config.php
- [x] database/schema.sql
- [x] .htaccess
- [x] index.php
- [x] webhook.php
- [x] check_system.php
- [x] composer.json

### Archivos a Crear en Servidor
- [ ] .env (manual con credenciales)
- [ ] logs/ (permisos 755)
- [ ] uploads/ (permisos 755)
- [ ] uploads/audios/ (permisos 755)
- [ ] uploads/documents/ (permisos 755)

### Configuración Servidor
- [ ] PHP 7.4+
- [ ] MySQL/MariaDB
- [ ] mod_rewrite habilitado
- [ ] Permisos: 755 carpetas, 644 archivos
- [ ] Base de datos importada

---

## 🚀 Para Nuevo Deployment

1. **Ejecutar:** `.\prepare_for_siteground.ps1`
2. **Resultado:** ZIP con todo lo necesario
3. **Subir a:** public_html/[carpeta]
4. **Extraer** el ZIP
5. **Crear** .env con credenciales
6. **Importar** database/schema.sql
7. **Configurar** permisos
8. **Verificar:** check_system.php

---

## 📊 Estadísticas del Proyecto

- **Total Archivos PHP:** 43
- **Endpoints API:** 15
- **Services:** 7
- **Views:** 5
- **Tamaño vendor/:** ~15MB
- **Tamaño total:** ~20MB

---

## 🎯 Características Implementadas

✅ WhatsApp Business Integration
✅ RAG (Retrieval Augmented Generation)
✅ Vector Search con cosine similarity
✅ Google Calendar Integration
✅ Audio transcription (Whisper)
✅ Multi-format document processing (PDF, DOCX, TXT)
✅ Conversational AI (GPT-4)
✅ Auto token refresh (Google Calendar)
✅ Dashboard administrativo
✅ Gestión de conversaciones
✅ Sistema de settings
✅ Health monitoring
✅ Error logging
✅ Dark mode UI
✅ Responsive design
✅ Subcarpeta support

---

## 🔒 Seguridad

✅ .env protegido por .htaccess
✅ Archivos ocultos bloqueados
✅ SQL injection protected (prepared statements)
✅ CSRF tokens en forms
✅ Input sanitization
✅ XSS protection headers
✅ No directory listing
✅ Secure file uploads

---

**Proyecto verificado y listo para deployment** ✅
