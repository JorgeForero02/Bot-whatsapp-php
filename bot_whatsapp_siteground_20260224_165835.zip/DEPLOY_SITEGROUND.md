# 🚀 Guía de Deployment en SiteGround

## 📋 Pre-requisitos

1. Cuenta de SiteGround activa
2. Dominio configurado
3. Acceso a File Manager o FTP
4. Base de datos MySQL creada en SiteGround

---

## 🔧 Paso 1: Preparar Archivos Localmente

### 1.1 Verificar que vendor existe
```bash
# En tu computadora, verifica que la carpeta vendor existe
# Debe contener: composer, guzzlehttp, phpoffice, psr, smalot
```

**IMPORTANTE:** La carpeta `vendor/` ya está lista en tu proyecto local. NO necesitas ejecutar composer.

### 1.2 Crear archivo ZIP para subir

Incluir estos archivos y carpetas:
- ✅ `vendor/` (COMPLETA con todas las subcarpetas)
- ✅ `src/`
- ✅ `config/`
- ✅ `database/`
- ✅ `api/`
- ✅ `views/`
- ✅ `workers/`
- ✅ `webhook.php`
- ✅ `index.php`
- ✅ `check_system.php`
- ✅ `.htaccess.siteground` (renombrar a `.htaccess` después de subir)

**NO incluir:**
- ❌ `.git/`
- ❌ `.env` (crear manualmente en servidor)
- ❌ `logs/` (crear manualmente)
- ❌ `uploads/` (crear manualmente)

---

## 📤 Paso 2: Subir Archivos a SiteGround

### Opción A: File Manager (Recomendado)

1. **Acceder a Site Tools:**
   - Login en [my.siteground.com](https://my.siteground.com)
   - Selecciona tu dominio
   - Click en "Site Tools"

2. **Ir a File Manager:**
   - Site → File Manager
   - Navega a `public_html/` o la carpeta de tu dominio

3. **Subir archivos:**
   - Click en "Upload"
   - Selecciona tu ZIP y súbelo
   - Click derecho en el ZIP → "Extract"
   - Borra el ZIP después de extraer

### Opción B: FTP

1. Usar FileZilla o cualquier cliente FTP
2. Conectar con credenciales de SiteGround
3. Subir todos los archivos a `public_html/`

---

## ⚙️ Paso 3: Configuración en SiteGround

### 3.1 Renombrar .htaccess

```bash
# En File Manager
1. Renombra `.htaccess.siteground` a `.htaccess`
2. Si ya existe un .htaccess, bórralo primero
```

### 3.2 Crear carpetas necesarias

```bash
# En File Manager, crear estas carpetas dentro de public_html:
- logs/
- uploads/
- uploads/audios/
- uploads/documents/
```

### 3.3 Configurar permisos

**Carpetas (755):**
- `logs/` → 755
- `uploads/` → 755
- `uploads/audios/` → 755
- `uploads/documents/` → 755
- `vendor/` → 755

**Archivos (644):**
- `webhook.php` → 644
- `index.php` → 644
- `.htaccess` → 644

**Para cambiar permisos:**
1. Click derecho en carpeta/archivo
2. "Change Permissions"
3. Ingresar número (755 o 644)

### 3.4 Crear archivo .env

```bash
# En File Manager, crear nuevo archivo llamado .env
# Copiar este contenido y ajustar valores:
```

```env
WHATSAPP_VERIFY_TOKEN=tu_verify_token_aqui
WHATSAPP_ACCESS_TOKEN=tu_whatsapp_token
WHATSAPP_PHONE_NUMBER_ID=tu_phone_id
WHATSAPP_API_VERSION=v17.0

OPENAI_API_KEY=tu_openai_key
OPENAI_MODEL=gpt-4-turbo-preview
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

DB_HOST=localhost
DB_NAME=tu_database_name
DB_USER=tu_database_user
DB_PASSWORD=tu_database_password
DB_PORT=3306

GOOGLE_CALENDAR_ACCESS_TOKEN=
GOOGLE_CALENDAR_REFRESH_TOKEN=
GOOGLE_CALENDAR_CLIENT_ID=
GOOGLE_CALENDAR_CLIENT_SECRET=
GOOGLE_CALENDAR_CALENDAR_ID=
GOOGLE_CALENDAR_TIMEZONE=America/Bogota

RAG_SIMILARITY_METHOD=cosine
```

**Importante:** Pide a SiteGround las credenciales de base de datos (DB_HOST, DB_NAME, DB_USER, DB_PASSWORD)

---

## 🗄️ Paso 4: Configurar Base de Datos

### 4.1 Crear base de datos

1. En Site Tools → MySQL → Databases
2. Click "Create Database"
3. Anota el nombre, usuario y contraseña

### 4.2 Importar schema

1. MySQL → phpMyAdmin
2. Selecciona tu base de datos
3. Click en "Import"
4. Sube el archivo `database/schema.sql`
5. Click "Go"

---

## 🧪 Paso 5: Verificar Instalación

### 5.1 Verificar sistema

Visita: `https://tudominio.com/check_system.php`

Esto mostrará:
- ✅ Versión de PHP (debe ser 7.4+)
- ✅ Extensiones requeridas
- ✅ Permisos de carpetas
- ✅ Conexión a base de datos
- ✅ Vendor y autoload
- ✅ Clases disponibles

**Todos deben estar en ✓ verde.**

### 5.2 Probar webhook

Visita: `https://tudominio.com/webhook.php?hub_mode=subscribe&hub_verify_token=TU_TOKEN&hub_challenge=test123`

Debe mostrar: `test123`

### 5.3 Borrar archivo de verificación

```bash
# Una vez verificado, BORRA check_system.php por seguridad
```

---

## 🔍 Solución de Problemas

### Error 500 - Internal Server Error

**Causas comunes:**

1. **Archivo .htaccess con error de sintaxis**
   - Renombra `.htaccess` a `.htaccess.old`
   - Crea nuevo `.htaccess` con contenido mínimo
   - Verifica que no haya líneas rotas

2. **Permisos incorrectos**
   - Carpetas: 755
   - Archivos: 644
   - NUNCA usar 777

3. **Versión de PHP incorrecta**
   - En Site Tools → PHP Manager
   - Cambiar a PHP 7.4 o superior
   - Preferiblemente PHP 8.0 o 8.1

4. **vendor/ faltante o incompleto**
   - Verifica que `vendor/autoload.php` existe
   - Debe tener subcarpetas: guzzlehttp, phpoffice, psr, smalot, composer

5. **Memoria PHP insuficiente**
   - En Site Tools → PHP Manager → PHP Options
   - Aumentar `memory_limit` a 512M
   - Aumentar `max_execution_time` a 60

### Ver logs de errores

1. Site Tools → Statistics → Error Log
2. Buscar errores recientes
3. Los errores de PHP están en `php_errorlog` dentro de cada carpeta

### Activar display de errores (solo para debugging)

Agrega al inicio de `webhook.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

**IMPORTANTE:** Quita estas líneas en producción.

---

## 🔐 Seguridad

### Archivos sensibles protegidos

El `.htaccess` ya protege:
- ✅ `.env` - No accesible desde web
- ✅ Archivos ocultos (comienzan con .)
- ✅ Índices de directorios deshabilitados

### Permisos correctos

```
Carpetas: 755 (rwxr-xr-x)
Archivos: 644 (rw-r--r--)
.env: 644 pero protegido por .htaccess
```

---

## 📞 Configurar Webhook en WhatsApp

Una vez todo funcionando:

```bash
# URL del webhook:
https://tudominio.com/webhook.php

# Verify Token: 
El que pusiste en .env como WHATSAPP_VERIFY_TOKEN
```

---

## ✅ Checklist Final

- [ ] Todos los archivos subidos (especialmente vendor/)
- [ ] .htaccess renombrado correctamente
- [ ] Carpetas logs/ y uploads/ creadas
- [ ] Permisos configurados (755 y 644)
- [ ] Archivo .env creado con credenciales correctas
- [ ] Base de datos importada (schema.sql)
- [ ] check_system.php muestra todo en verde
- [ ] webhook.php responde correctamente
- [ ] check_system.php eliminado después de verificar
- [ ] Versión PHP 7.4+ seleccionada en PHP Manager
- [ ] Webhook configurado en WhatsApp Business

---

## 🆘 Soporte

Si sigues teniendo error 500:

1. Verifica Error Log en Site Tools
2. Revisa que vendor/ esté completa
3. Confirma versión de PHP
4. Verifica permisos de carpetas
5. Asegúrate que .env tiene credenciales correctas de DB

**El proyecto NO requiere ejecutar composer en SiteGround** - todo está incluido en vendor/.
