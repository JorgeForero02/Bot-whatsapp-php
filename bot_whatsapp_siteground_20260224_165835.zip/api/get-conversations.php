<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Config;
use App\Core\Database;
use App\Core\Logger;
use App\Services\ConversationService;

$config = Config::load(__DIR__ . '/../config/config.php');
$db = Database::getInstance(Config::get('database'));
$logger = new Logger(__DIR__ . '/../logs');

header('Content-Type: application/json');

try {
    $conversationService = new ConversationService($db);

    $status = $_GET['status'] ?? null;
    $conversations = $conversationService->getAllConversations($status);

    foreach ($conversations as &$conversation) {
        $messages = $conversationService->getConversationHistory($conversation['id'], 10);
        $conversation['recent_messages'] = array_reverse($messages);
    }

    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);

} catch (\Exception $e) {
    $logger->error('Get Conversations Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
